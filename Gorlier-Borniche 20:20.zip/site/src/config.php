<?php
 $config['serveur'] ='localhost';
 $config['login']   ='alolu';
 $config['mdp']     ='famille';
 $config['bd']      ='SI5P1';
?>
