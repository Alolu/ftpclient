<?php
 entete();
 menu();
 echo'Bienvenue sur mon site ';
 bas();
?>
